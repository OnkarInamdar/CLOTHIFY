import { FaBoxOpen, FaHome, FaShoppingCart, FaStore, FaThList } from "react-icons/fa";
import { bannerImageOne, bannerImageThree, bannerImageTwo } from "./constant";

export const bannerLists = [
    {
        id: 1,
        image: bannerImageOne,
        title: "Elegant Tops",
        subtitle: "Summer Styles 2025",
        description: "Fresh and stylish tops for every day."
    },
    {
        id: 2,
        image: bannerImageTwo,
        title: "Graceful Sarees",
        subtitle: "Traditional & Trendy",
        description: "Beautiful sarees for every occasion."
    },
    {
        id: 3,
        image: bannerImageThree,
        title: "Classic Pants",
        subtitle: "Comfort Meets Style",
        description: "Smart, comfortable pants you'll love."
    }
];



export const adminNavigation = [
  {
    name: "Dashboard", 
    href: "/admin", 
    icon: FaHome, 
    current: true 
  }, {
    name: "Orders", 
    href: "/admin/orders", 
    icon: FaShoppingCart
  }, {
    name: "Products", 
    href: "/admin/products", 
    icon: FaBoxOpen
  }, {
    name: "Categories", 
    href: "/admin/categories", 
    icon: FaThList
  }, {
    name: "Sellers", 
    href: "/admin/sellers", 
    icon: FaStore 
  }
];


export const sellerNavigation = [
  {
    name: "Orders", 
    href: "/admin/orders", 
    icon: FaShoppingCart,
    current: true 
  }, {
    name: "Products", 
    href: "/admin/products", 
    icon: FaBoxOpen
  }
];